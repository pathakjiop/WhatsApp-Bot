const { handleMessage } = require("./message.controller");
const whatsappService = require("../services/whatsapp.service");

class WebhookController {
  constructor() {
    this.handleWebhook = this.handleWebhook.bind(this);
    this.verify = this.verify.bind(this);
  }

  // ======================
  // WEBHOOK VERIFICATION
  // ======================
  async verify(req, res) {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    console.log("🔍 Webhook verification attempt:");
    console.log(`Mode: ${mode}`);
    console.log(`Token: ${token}`);
    console.log(`Expected: ${process.env.VERIFY_TOKEN}`);

    if (mode === "subscribe" && token === process.env.VERIFY_TOKEN) {
      console.log("✅ Webhook verified successfully");
      return res.status(200).send(challenge);
    }

    console.log("❌ Webhook verification failed");
    return res.sendStatus(403);
  }

  // ======================
  // MAIN WEBHOOK HANDLER
  // ======================
  async handleWebhook(req, res) {
    try {
      console.log("📨 RAW WEBHOOK RECEIVED:", JSON.stringify(req.body, null, 2));

      const entryList = req.body?.entry;
      if (!Array.isArray(entryList)) {
        console.log("⚠️ No entry array");
        return res.status(200).send("EVENT_RECEIVED");
      }

      for (const entry of entryList) {
        const changes = entry?.changes;
        if (!Array.isArray(changes)) continue;

        for (const change of changes) {
          const value = change?.value;
          if (!value) continue;

          if (Array.isArray(value.messages)) {
            await this.handleIncomingMessages(value);
          } 
          else if (Array.isArray(value.statuses)) {
            await this.handleStatusUpdates(value);
          } 
          else if (value.errors) {
            await this.handleErrors(value);
          } 
          else {
            console.log("🤔 Unknown webhook payload:", Object.keys(value));
          }
        }
      }

      res.status(200).send("EVENT_RECEIVED");

    } catch (error) {
      console.error("❌ Webhook processing error:", error);
      res.status(200).send("EVENT_RECEIVED"); // NEVER 500
    }
  }

  // ======================
  // INCOMING MESSAGES
  // ======================
  async handleIncomingMessages(value) {
    const messages = value.messages || [];
    console.log(`📩 Received ${messages.length} message(s)`);

    for (const message of messages) {
      console.log("\n📱 Message Details:");
      console.log(`From: ${message.from}`);
      console.log(`Type: ${message.type}`);
      console.log(`ID: ${message.id}`);
      console.log(`Timestamp: ${message.timestamp}`);

      try {
        if (message.type === "text") {
          console.log(`Text: ${message.text.body}`);
          await handleMessage(message.from, message.text.body);

        } else if (message.type === "interactive") {
          const replyId =
            message.interactive?.button_reply?.id ||
            message.interactive?.list_reply?.id;

          console.log(`Interactive reply: ${replyId}`);
          await handleMessage(message.from, replyId);

        } else if (message.type === "button") {
          console.log(`Button: ${message.button.text}`);
          await handleMessage(message.from, message.button.text);

        } else {
          console.log(`Unhandled message type: ${message.type}`);
          await whatsappService.sendTextMessage(
            message.from,
            "I can only process text messages right now. Please send 'hi'."
          );
        }

      } catch (err) {
        console.error("❌ Message handling error:", err.message);
      }
    }
  }

  // ======================
  // STATUS UPDATES
  // ======================
  async handleStatusUpdates(value) {
    const statuses = value.statuses || [];
    console.log(`📊 Status updates: ${statuses.length}`);

    for (const status of statuses) {
      console.log(`Message ${status.id}: ${status.status}`);
    }
  }

  // ======================
  // ERROR HANDLING
  // ======================
  async handleErrors(value) {
    const errors = Array.isArray(value.errors)
      ? value.errors
      : [value.errors];

    console.log(`❌ Errors received: ${errors.length}`);

    for (const error of errors) {
      console.log(`Error ${error.code}: ${error.title}`);
      console.log(`Details: ${error.message}`);
    }
  }
}

module.exports = new WebhookController();
